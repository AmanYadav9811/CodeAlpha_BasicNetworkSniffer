from scapy.all import sniff

def packet_callback(packet):
    if packet.haslayer("IP"):
        ip_layer = packet["IP"]
        print(f"[+] {ip_layer.src} --> {ip_layer.dst} | Protocol: {ip_layer.proto}")

print("🚀 Starting Basic Network Sniffer... Press CTRL+C to stop.")
sniff(prn=packet_callback, store=False)
