from scapy.all import sniff, wrpcap
import os

# List to store captured packets
captured_packets = []

# Create folder for pcap if not exists
if not os.path.exists("pcap_files"):
    os.mkdir("pcap_files")

def packet_callback(packet):
    captured_packets.append(packet)  # store packet

    # Check if IP layer exists
    if packet.haslayer("IP"):
        ip_layer = packet["IP"]
        proto = ip_layer.proto
        print(f"[+] {ip_layer.src} --> {ip_layer.dst} | Protocol: {proto}")

        # Show TCP/UDP payloads
        if packet.haslayer("TCP"):
            print("   TCP Payload:", bytes(packet["TCP"].payload))
        elif packet.haslayer("UDP"):
            print("   UDP Payload:", bytes(packet["UDP"].payload))

    # Save every 50 packets
    if len(captured_packets) % 50 == 0:
        wrpcap("pcap_files/captured_packets.pcap", captured_packets)
        print(f" Saved {len(captured_packets)} packets to pcap_files/captured_packets.pcap")

# Optional: Filter packets (TCP only, UDP only, or HTTP)
packet_filter = input("Enter filter (tcp/udp/http/none): ").lower()
filter_str = None
if packet_filter == "tcp":
    filter_str = "tcp"
elif packet_filter == "udp":
    filter_str = "udp"
elif packet_filter == "http":
    filter_str = "tcp port 80"

print(" Starting Intermediate Network Sniffer... Press CTRL+C to stop.")
sniff(prn=packet_callback, filter=filter_str, store=False)

